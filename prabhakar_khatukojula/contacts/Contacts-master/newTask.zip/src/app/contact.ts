export interface Contact {
    name:string
    label: string,
    number:number,
      email: string,
      id:number
}